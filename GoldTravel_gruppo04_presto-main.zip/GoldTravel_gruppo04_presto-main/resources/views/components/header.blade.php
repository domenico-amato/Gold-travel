<div id="header" class="d-flex align-items-end header-image ps-3">
    <h1 class="fontBord shadow-custom m-0 p-1">
        <span id="show">{!! $header !!}</span><span id="hidden" class="d-none">Valle d'Aosta</span>
    </h1>
</div>