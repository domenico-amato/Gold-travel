import './bootstrap';
import 'bootstrap';
import './script.js';

